# OurDataset > 2023-05-20 4:52am
https://universe.roboflow.com/weeddetection-qkejh/ourdataset-x8mkj

Provided by a Roboflow user
License: CC BY 4.0

